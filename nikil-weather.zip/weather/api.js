function getWeather(){
    var city = document.getElementById('inputValue').value;
    var nameval = document.getElementById('name');
    var temp = document.getElementById('temp');
    var desc = document.getElementById('desc');


fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&APPID=51b2167f2d4528282cde0f0c4bce52c7`)
.then(function(response){
    return response.json();

})

.then(function(data){
    nameval.innerText = data.name;
    temp.innerText = data.main.temp + "C";
    desc.innerText = data.weather[0].main;
})
.catch(function(){
    alert("city is not found");
});
}
 
document.getElementById('button').addEventListener('click', getWeather)
